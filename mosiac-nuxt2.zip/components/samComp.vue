<template>
  <div>
    This is my Sample Component
    <h1 class="text-3xl font-bold underline flex justify-center">
      Hello world!
    </h1>

    <div>
      <h1 class="text-3xl font-bold underline">From inside the div</h1>
    </div>
  </div>
</template>

<script>
export default {
  setup() {
    return {};
  },
};
</script>

<style scoped>
</style>